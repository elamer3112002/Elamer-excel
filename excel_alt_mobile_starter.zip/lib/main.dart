import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/input_screen.dart';
import 'screens/tabs_screen.dart';
import 'screens/reports_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Lock to portrait for data entry clarity
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const ExcelAltApp());
}

class ExcelAltApp extends StatelessWidget {
  const ExcelAltApp({super.key});

  @override
  Widget build(BuildContext context) {
    final baseTheme = ThemeData(
      useMaterial3: true,
      visualDensity: VisualDensity.adaptivePlatformDensity,
      fontFamily: GoogleFonts.cairo().fontFamily,
      textTheme: GoogleFonts.cairoTextTheme(),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      title: 'بديل الإكسيل',
      theme: baseTheme.copyWith(
        textTheme: baseTheme.textTheme.apply(fontSizeFactor: 1.15), // خط كبير وواضح
      ),
      home: const TabsScreen(),
      routes: {
        InputScreen.routeName: (_) => const InputScreen(),
        ReportsScreen.routeName: (_) => const ReportsScreen(),
      },
    );
  }
}