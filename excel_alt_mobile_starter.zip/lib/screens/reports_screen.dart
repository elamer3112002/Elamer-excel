import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../db/app_db.dart';

class ReportsScreen extends StatefulWidget {
  static const routeName = '/reports';
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  int _year = DateTime.now().year;
  final _num = NumberFormat('##0.000', 'ar_EG');

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is int) _year = args;
  }

  Future<File> _buildSupplierComparePDF() async {
    final data = await AppDB.instance.supplierCompare(_year);
    final doc = pw.Document();
    final font = await rootBundle.load('assets/fonts/Cairo-Regular.ttf');
    final ttf = pw.Font.ttf(font);
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      build: (ctx){
        return pw.Directionality(
          textDirection: pw.TextDirection.rtl,
          child: pw.Column(children: [
            pw.Text('تقرير مقارنة المورد ${_year} مقابل ${_year-1}', style: pw.TextStyle(font: ttf, fontSize: 18)),
            pw.SizedBox(height: 10),
            pw.Table.fromTextArray(
              headerStyle: pw.TextStyle(font: ttf, fontSize: 12, fontWeight: pw.FontWeight.bold),
              cellStyle: pw.TextStyle(font: ttf, fontSize: 11),
              headers: ['المورد','كمية الحالي','كمية العام السابق','نسبة التغير ٪'],
              data: data.map((m)=>[
                m['المورد'] ?? '',
                _num.format((m['كمية_الحالي'] ?? 0)),
                _num.format((m['كمية_العام_السابق'] ?? 0)),
                m['نسبة_التغير_٪'] == null ? '-' : _num.format(m['نسبة_التغير_٪']),
              ]).toList(),
              cellAlignment: pw.Alignment.centerRight,
            ),
          ]),
        );
      }
    ));
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/تقرير_المورد_$_year.pdf');
    await f.writeAsBytes(await doc.save());
    return f;
  }

  Future<File> _buildCapacityVsActualPDF() async {
    final data = await AppDB.instance.capacityVsActual(_year);
    final doc = pw.Document();
    final font = await rootBundle.load('assets/fonts/Cairo-Regular.ttf');
    final ttf = pw.Font.ttf(font);
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      build: (ctx){
        return pw.Directionality(
          textDirection: pw.TextDirection.rtl,
          child: pw.Column(children: [
            pw.Text('السعة المقررة مقابل المورد الفعلي — $_year', style: pw.TextStyle(font: ttf, fontSize: 18)),
            pw.SizedBox(height: 10),
            pw.Table.fromTextArray(
              headerStyle: pw.TextStyle(font: ttf, fontSize: 12, fontWeight: pw.FontWeight.bold),
              cellStyle: pw.TextStyle(font: ttf, fontSize: 11),
              headers: ['النوع','المورد','السعة المقررة','المورد الفعلي','نسبة الامتلاء ٪'],
              data: data.map((m)=>[
                m['النوع'] ?? '',
                m['المورد'] ?? '',
                _num.format((m['السعة_المقررة'] ?? 0)),
                _num.format((m['المورد_الفعلي'] ?? 0)),
                m['نسبة_الامتلاء_٪'] == null ? '-' : _num.format(m['نسبة_الامتلاء_٪']),
              ]).toList(),
              cellAlignment: pw.Alignment.centerRight,
            ),
          ]),
        );
      }
    ));
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/السعة_مقابل_المورد_$_year.pdf');
    await f.writeAsBytes(await doc.save());
    return f;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التقارير والطباعة A4')),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Text('السنة:'),
                  IconButton(onPressed: ()=>setState(()=>_year--), icon: const Icon(Icons.remove)),
                  Text('$_year', style: const TextStyle(fontWeight: FontWeight.bold)),
                  IconButton(onPressed: ()=>setState(()=>_year++), icon: const Icon(Icons.add)),
                ],
              ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('طباعة تقرير مقارنة المورد'),
                onPressed: () async {
                  final f = await _buildSupplierComparePDF();
                  if (mounted) await Printing.sharePdf(bytes: await f.readAsBytes(), filename: f.path.split('/').last);
                },
              ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('طباعة تقرير السعة المقررة مقابل المورد الفعلي'),
                onPressed: () async {
                  final f = await _buildCapacityVsActualPDF();
                  if (mounted) await Printing.sharePdf(bytes: await f.readAsBytes(), filename: f.path.split('/').last);
                },
              ),
              const SizedBox(height: 10),
              const Text('ملاحظة: تأكد من إضافة خط عربي (Cairo.ttf) في assets لضمان تنسيق PDF بالعربي.'),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: ()=>Navigator.pop(context),
        icon: const Icon(Icons.home),
        label: const Text('الرئيسية'),
      ),
    );
  }
}