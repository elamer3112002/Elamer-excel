import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import '../models/record.dart';

class AppDB {
  static final AppDB instance = AppDB._();
  AppDB._();

  Database? _db;
  String get table => 'السجلات';

  Future<Database> get database async {
    if (_db != null) return _db!;
    final Directory dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'excel_alt.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE $table (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            "اسم_البنك" TEXT NOT NULL,
            "القطاع" TEXT NOT NULL,
            "النوع" TEXT NOT NULL,
            "السعة" REAL NOT NULL,
            "المورد" TEXT NOT NULL,
            "اسم_الأمين" TEXT NOT NULL,
            "اسم_الفراز" TEXT NOT NULL,
            "المورد_بالدرجات" TEXT NOT NULL,
            "الكمية" REAL NOT NULL,
            "المنقول_للصوامع" REAL NOT NULL,
            "المسلم_للمطاحن" REAL NOT NULL,
            "الزيادات" REAL NOT NULL,
            "الأرصدة" REAL NOT NULL,
            "برامج_السحب" TEXT NOT NULL,
            "ملفPDF" TEXT,
            "السنة" INTEGER NOT NULL
          );
        ''');
        // فهارس للأداء
        await db.execute('CREATE INDEX idx_year ON $table("السنة");');
        await db.execute('CREATE INDEX idx_type ON $table("النوع");');
        await db.execute('CREATE INDEX idx_supplier ON $table("المورد");');
      },
    );
    return _db!;
  }

  Future<int> insert(Record r) async {
    final db = await database;
    return db.insert(table, r.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Record>> queryByType(String type, int year) async {
    final db = await database;
    final rows = await db.query(
      table,
      where: '"النوع"=? AND "السنة"=?',
      whereArgs: [type, year],
      orderBy: 'id DESC',
    );
    return rows.map((e) => Record.fromMap(e)).toList();
  }

  Future<List<Record>> queryYear(int year) async {
    final db = await database;
    final rows = await db.query(table, where: '"السنة"=?', whereArgs: [year]);
    return rows.map((e) => Record.fromMap(e)).toList();
  }

  // تقارير: مقارنة المورد الحالي بالعام السابق
  Future<List<Map<String, Object?>>> supplierCompare(int year) async {
    final db = await database;
    final prev = year - 1;
    return db.rawQuery('''
      WITH curr AS (
        SELECT "المورد" AS s, SUM("الكمية") AS q
        FROM $table WHERE "السنة"=? GROUP BY "المورد"
      ),
      prev AS (
        SELECT "المورد" AS s, SUM("الكمية") AS q
        FROM $table WHERE "السنة"=? GROUP BY "المورد"
      )
      SELECT COALESCE(curr.s, prev.s) AS المورد,
             COALESCE(curr.q, 0) AS كمية_الحالي,
             COALESCE(prev.q, 0) AS كمية_العام_السابق,
             CASE WHEN COALESCE(prev.q,0)=0 THEN NULL
                  ELSE ROUND( (COALESCE(curr.q,0)-COALESCE(prev.q,0)) * 100.0 / prev.q , 3) END AS نسبة_التغير_٪
      FROM curr
      FULL OUTER JOIN prev ON curr.s = prev.s;
    ''', [year, prev]);
  }

  // تقارير: السعة المقررة مقابل المورد الفعلي
  Future<List<Map<String, Object?>>> capacityVsActual(int year) async {
    final db = await database;
    return db.rawQuery('''
      SELECT "النوع", "المورد",
             SUM("السعة") AS السعة_المقررة,
             SUM("الكمية") AS المورد_الفعلي,
             CASE WHEN SUM("السعة")=0 THEN NULL
                  ELSE ROUND(SUM("الكمية")*100.0/SUM("السعة"),3) END AS نسبة_الامتلاء_٪
      FROM $table WHERE "السنة"=?
      GROUP BY "النوع","المورد"
      ORDER BY "النوع","المورد";
    ''', [year]);
  }
}